export const Text1 = 'Gönn deinem LEGO Land Rover einen Hauch von "Ich brauche mehr Platz für meine LEGO-Abenteuer" mit unserem Dachträger. Weil wer braucht schon Kompromisse, wenn man auch einfach das ganze LEGO-Universum aufs Dach packen kann? Einmal Dachträger montiert, und schon kann die Minifigur-Welttour beginnen!';

export const Text2 = 'Verleihe deinem LEGO Land Rover das ultimative Kopfbedeckungs-Upgrade – das Dach für den modischen Minifiguren-Fahrer von heute! Zeig der LEGO-Nachbarschaft, dass dein Auto nicht nur fährt, sondern auch einen großartigen Sinn für Stil hat. Cabrio war gestern, heute trägt man LEGO-Dächer!';

export const Text3 = 'Unsere LEGO Land Rover Karosserie macht aus deinem Auto mehr als nur ein Spielzeug – sie macht es zu einem Statement. Stell dir vor, wie die anderen LEGO-Fahrzeuge vor Neid erblassen, wenn dein Land Rover vorbeifährt!';

export const Text4 = 'Mit unserer LEGO Land Rover Motorhaube wird dein Modell zum Hingucker der Klötzchen-Straße. Denn warum sollte dein LEGO Auto unter der Haube nicht genauso beeindruckend aussehen wie du? Diese Motorhaube sagt: "Ich mag meine LEGO-Steine genauso heiß, wie meine Kaffeetasse."';

export const Text5 = 'Unsere LEGO Land Rover Reifen – für die Minifigur, die nicht nur fahren, sondern auch eine Spur von Coolness hinterlassen will. Mach Schluss mit langweiligen Rädern und gönn deinem LEGO Auto das Upgrade, das es verdient. Diese Reifen sagen: "Ich rolle nicht einfach, ich stylee!"';

export const Text6 = 'Die LEGO Land Rover Seitenspiegel – weil auch Mini-Fahrzeuge das Bedürfnis nach einem schnellen Blick in den Rückspiegel haben. Zeig der LEGO-Welt, dass du nicht nur nach vorne fährst, sondern auch im Rückspiegel noch cooler aussiehst. Ein bisschen Egoismus im Straßenverkehr hat noch keinem geschadet!';

export const Text7 = 'Weil wer braucht schon einen sauberen LEGO Land Rover? Unser Spritzschutz verpasst deinem Geländewagen den authentischen "Ich war gerade Offroad"-Vibe – und das ohne das Auto deines Nachbarn zu verschonen. Schließlich zeigt wahre LEGO-Patriotismus sich erst, wenn man bereit ist, ein bisschen Klötzchen-Staub zu verteilen.';
